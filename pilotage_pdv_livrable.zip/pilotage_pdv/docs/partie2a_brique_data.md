# Partie 2a — La brique data : pipeline, connecteurs et gouvernance

> Paragraphe destiné au dossier PDF (Partie 2 — conception et développement).
> À reformuler à ta voix ; les chiffres et noms de fichiers sont à adapter.

## 1. Rôle de la brique data dans la solution

La valeur de l'application ne vient pas seulement de son interface, mais de la
**fiabilité des indicateurs** qu'elle affiche. Or ces indicateurs sont calculés
à partir de fichiers de ventes hétérogènes, produits par des systèmes de caisse
différents selon les points de vente. La brique data a donc une mission précise :
**transformer une source brute et variable en un entrepôt normalisé et fiable**,
sur lequel les KPI peuvent être calculés sans risque.

Cette brique est implémentée en Python avec **pandas** pour le traitement et
**SQLAlchemy** pour le chargement, et se décompose en quatre étapes rendues
visibles à l'utilisateur (écran « Import de données »).

## 2. Le schéma de collecte : une cible stable, une source libre

Le point de conception central est la distinction entre la **source** et la
**cible**.

- La **cible** est le schéma de l'entrepôt : chaque ligne de vente doit fournir
  une `date`, un `produit`, une `quantité` et un `montant`. C'est le minimum
  nécessaire au calcul des KPI (chiffre d'affaires, panier moyen, top produits,
  pics horaires). Ce schéma est **stable** et non négociable.
- La **source** est le fichier réel envoyé par un magasin. Ses colonnes peuvent
  porter des noms différents (`date_commande`, `order_date`, `article`, `qte`,
  `prix`…), utiliser un séparateur différent (`,` ou `;`) ou un format de date
  différent. La source est donc **variable**.

Concevoir un pipeline robuste, c'est refuser de coupler ces deux niveaux. Une
première version exigeait des noms de colonnes exacts : elle ne fonctionnait que
pour un seul format d'export et cassait pour tous les autres magasins. La version
retenue introduit une **couche de correspondance (mapping)** entre la source et
la cible.

## 3. Le connecteur : une couche de correspondance (mapping)

Concrètement, l'ingestion d'un fichier se fait désormais en deux temps :

1. **Détection.** À la réception du fichier, le pipeline lit uniquement les
   en-têtes et un échantillon de lignes. Un **dictionnaire d'alias** associe
   automatiquement les colonnes reconnues aux champs cibles (par exemple
   `date_commande`, `orderdate` ou `horodatage` sont reconnus comme le champ
   `date`). La comparaison est faite après normalisation (suppression des
   accents, de la casse et des séparateurs), pour tolérer les variantes
   d'écriture.
2. **Correspondance confirmée.** L'utilisateur visualise un aperçu de son fichier
   et une proposition de correspondance pré-remplie. Il confirme ou ajuste
   l'association de chaque champ, puis lance le traitement. Les colonnes non
   reconnues automatiquement sont associées manuellement en un clic.

Cette approche est celle des outils d'ingestion professionnels (import de
catalogues, connecteurs SaaS) : elle rend la solution **indépendante du format
d'export** et donc réellement déployable sur l'ensemble d'un parc de magasins,
sans redéveloppement pour chaque nouvelle source.

**Recomposition de l'horodatage.** Certains exports de caisse séparent la date
(`2026-01-01`) et l'heure (`11:38:36`) en deux colonnes distinctes. Le connecteur
accepte donc une colonne « heure » facultative et **recompose l'horodatage
complet** avant l'analyse. L'enjeu est loin d'être cosmétique : les lignes étant
regroupées en commandes par horodatage, une date sans heure agrégerait toutes les
ventes d'une journée en une seule commande — faussant le nombre de commandes, le
panier moyen et les pics horaires. Deux garde-fous accompagnent la règle : si la
colonne date porte déjà une heure, elle fait foi (pas de double heure) ; si
l'heure est absente ou illisible sur une ligne, la date seule est conservée —
l'heure est une précision, pas une condition de validité.

## 4. La gouvernance : contrôles qualité et traçabilité

La donnée n'est jamais chargée telle quelle. Avant l'intégration, chaque ligne
passe une série de **contrôles qualité**, dont le résultat est affiché à
l'utilisateur (transparence) :

- **Valeurs manquantes** — une ligne sans date, produit, quantité ou montant est
  rejetée.
- **Cohérence de format** — les dates sont validées contre plusieurs formats
  connus ; une date impossible (par exemple un mois « 13 ») est rejetée.
- **Validité métier** — une quantité doit être un entier strictement positif, un
  montant un nombre positif (la virgule décimale est acceptée).
- **Doublons** — deux lignes strictement identiques (même date, produit,
  quantité, montant) sont dédupliquées.

### Idempotence : un import rejouable sans fausser les indicateurs

Un contrôle qualité ligne à ligne ne suffit pas : il dédoublonne *à l'intérieur*
d'un fichier, mais rien n'empêche de réimporter deux fois le même fichier — et
de doubler mécaniquement le chiffre d'affaires. Le pipeline garantit donc
l'**idempotence entre imports**, par deux couches complémentaires :

- **Empreinte du fichier.** Un hachage SHA-256 du contenu est calculé et
  journalisé. Si un import réussi porte déjà la même empreinte, l'interface
  avertit (« ce fichier a déjà été importé le … ») et **bloque par défaut** la
  réintégration, avec une option explicite pour poursuivre.
- **Clé d'idempotence par ligne.** Chaque ligne reçoit une clé déterministe
  dérivée de ses données métier (date, produit normalisé, quantité, montant),
  soumise à une contrainte d'unicité en base. À l'intégration, une ligne dont la
  clé existe déjà est **ignorée**, jamais réinsérée. Cette couche est la plus
  robuste : elle couvre aussi le cas d'un fichier mêlant des lignes déjà connues
  et des lignes nouvelles (recouvrement partiel).

Conformément au principe de **rejet mesuré et non silencieux**, ces lignes
ignorées ne disparaissent pas : elles sont comptées séparément des lignes
rejetées, affichées dans le récapitulatif d'import et conservées dans le journal
`import_fichier`. Réimporter un fichier connu affiche ainsi explicitement :
*186 lues · 0 intégrées · 186 ignorées* — et les indicateurs restent inchangés.

Seules les lignes valides et nouvelles sont chargées dans l'entrepôt via l'ORM. Les lignes de
vente partageant le même horodatage sont regroupées en une **commande** (ticket),
et le montant total de la commande est recalculé à l'intégration.

Enfin, **chaque import est journalisé** dans la table `import_fichier` : nom du
fichier, utilisateur, date, nombre de lignes lues, nombre de lignes rejetées et
statut. Cette traçabilité permet d'auditer l'historique des chargements et de
suivre la qualité des sources dans le temps — un réflexe de gouvernance des
données indispensable dès qu'un pipeline alimente des indicateurs de décision.

## 4 bis. La table `vente` (système source Pulse)

Le modèle inclut une table `vente`, issue du **système source réel de Domino's
(Pulse)** : elle enregistre l'**encaissement** d'une commande et son **mode de
paiement** (Carte, Espèces, Ticket resto). Deux points de conception importants :

- **Source unique de vérité pour le CA.** La table `vente` ne sert *jamais* au
  calcul du chiffre d'affaires. Le CA reste calculé exclusivement à partir de
  `ligne_commande`. On évite ainsi d'avoir deux sources qui finiraient par
  diverger ; `vente.montant` reflète l'encaissement et reste cohérent avec le
  montant de la commande.
- **Périmètre maîtrisé.** Les autres tables de Pulse (Clients, Stock, Employés,
  Livraisons) sont volontairement **hors périmètre** : le projet vise le pilotage
  de la performance, pas la gestion opérationnelle complète. La table `vente`
  apporte une exploitation concrète — la **répartition des encaissements par mode
  de paiement**, affichée sur l'écran d'analyse des ventes.

Côté pipeline, `mode_paiement` est un **champ facultatif** de la couche de
correspondance : reconnu automatiquement s'il est présent dans le fichier,
simplement ignoré sinon (aucune erreur).

## 5. Ce que cette conception démontre

- **Séparation source / cible** : le schéma d'entrepôt reste stable, la variété
  des sources est absorbée par une couche de mapping.
- **Contrôles qualité explicites** : la fiabilité des KPI est garantie *avant*
  affichage, et le rejet est mesuré, pas silencieux.
- **Traçabilité** : chaque chargement laisse une trace exploitable.

## 6. Limites et évolutions envisagées

- **Profils de source mémorisés** : à ce stade, la correspondance est confirmée à
  chaque import. Une évolution naturelle consiste à **mémoriser un profil de
  mapping par magasin / par source**, pour que les imports suivants soient
  entièrement automatiques — c'est la définition d'un véritable connecteur ETL.
- **Orchestration** : le traitement est aujourd'hui déclenché manuellement. Sur
  un parc de magasins, une **orchestration planifiée** (par exemple avec un
  ordonnanceur type Airflow) permettrait des imports récurrents et supervisés.
- **Traitement asynchrone** : pour de très gros volumes, déporter le traitement
  dans une file de tâches éviterait de bloquer la requête web.
